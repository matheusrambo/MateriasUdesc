import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;
import java.util.concurrent.*;
import java.io.*;
import java.nio.file.Paths;


class Par{
  public String user;
  public String msg;

  public Par (final String usuario, final String message) {
    user = usuario;
    msg = message;
  }
}

class Fila {
  public String owner;
  public CopyOnWriteArrayList<Par> queue;

  public Fila(final String nome) {
    owner = nome;
    queue = new CopyOnWriteArrayList<Par>();
  }
}

public class Servidor implements idl {
  private static int maxUsers = 10;
  private static CopyOnWriteArrayList<Fila> usersList;

  public Servidor() {
  }

  public static void main(final String[] args) {
    try {
      // Instancia o objeto servidor e a sua stub
      final Servidor server = new Servidor();
      final idl stub = (idl) UnicastRemoteObject.exportObject(server, 0);
      // Registra a stub no RMI Registry para que ela seja obtAida pelos clientes
      final Registry registry = LocateRegistry.createRegistry(6600);
      // Registry registry = LocateRegistry.getRegistry(9999);
      usersList = new CopyOnWriteArrayList<Fila>();
      registry.bind("sendMsg", stub);
      registry.bind("getMsg", stub);
      registry.bind("getMsgUser", stub);
      registry.bind("disconnect", stub);
      registry.bind("connect", stub);
      System.out.println("Servidor pronto!");
    } catch (final Exception ex) {
      ex.printStackTrace();
    }
  }

  public int sendMsg(final String name, final String msg) throws RemoteException {
    System.out.println(name + " enviou uma mensagem: ");
    for (final Fila a : usersList) {
      if (!a.owner.equals(name)) {
        final Par parpar = new Par(name, msg);
        a.queue.add(parpar);
      }
    }
    return 0;
  }

  public String getMsg(final String name) throws RemoteException {
    System.out.println(name + " pediu uma mensagem da sua fila");
    for (final Fila a : usersList) {
      if (a.owner.equals(name)) {
        if (!a.queue.isEmpty()) {
          final String mensagem = a.queue.get(0).msg;
          a.queue.remove(0);
          return mensagem;
        }
      }
    }
    return "";
  }

  public String getMsgUser(final String name) throws RemoteException {
    System.out.println(name + " pediu o usuario da msg da fila propria");
    for (final Fila a : usersList) {
      if (a.owner.equals(name)) {
        if (!a.queue.isEmpty()) {
          return a.queue.get(0).user;
        }
      }
    }
    return "";
  }

  public boolean connect(final String name) throws RemoteException {
    System.out.println(name + " tentando se conectar");
    for (final Fila a : usersList) {
      if (a.owner.equals(name)) {
        System.out.println(name + " usuario ja utilizado!");
        return false;
      }
    }
    if (usersList.size() >= maxUsers) {
      System.out.println(name + " servidor cheio!");
      return false;
    }
    final Fila fila = new Fila(name);
    usersList.add(fila);
    System.out.println(name + " se conectou!");
    return true;
  }

  public boolean disconnect(final String name) throws RemoteException {
    for (final Fila a : usersList) {
      if (a.owner.equals(name)) {
        usersList.remove(a);
        System.out.println("bye " + name);
        return true;
      }
    }
    System.out.println("O usuario " + name + " não existe!");
    return false;
  }

  public int salvar(final String pastauser, final String name, final String msg) throws RemoteException {
    final byte[] inBuf = new byte[5000000];
    final String resLinha = "";
    String filename;
    int counter = 1;

    try {
      if (!Paths.get(pastauser).toFile().exists()) {
        final File dir = new File(pastauser + "/");
        dir.mkdirs();
      }
      while (true) {
        if (counter > 9) {
          filename = pastauser + "/" + name + "-" + counter + ".serv";
        } else {
          filename = pastauser + "/" + name + "-0" + counter + ".serv";
        }
        if (Paths.get(filename).toFile().exists()) {
          counter++;
          continue;
        } else {
          final FileWriter fw = new FileWriter(filename);
          final BufferedWriter bw = new BufferedWriter(fw);
          bw.write(msg);
          bw.close();
          break;
        }
      }
    } catch (final IOException e) {
        System.out.println("IOException:  " + e);
      }
      return 0;
    }

  }