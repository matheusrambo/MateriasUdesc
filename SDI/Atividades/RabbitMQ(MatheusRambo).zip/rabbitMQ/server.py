#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pika, threading, socket, random

#Funcao que gera um id aleatorio para um cliente e armazena no dicionario de clientes
def gera_id_cliente(user, sock):
        id_user = random.randint(0, 1000)

        while id_user in reg_clientes.keys():
                id_user = random.randint(0, 1000)

        reg_clientes[id_user] = user.decode()
        sock.send(str(id_user).encode())

#Funcao para verificar a conexao de novos clientes
def polling_cliente():
	while polling:
		s.listen(1)
		conn, addr = s.accept()
		data = conn.recv(1024)
		data = data.rstrip()
		gera_id_cliente(data, conn)
		print ("Cliente conectado: ", data.decode())

#Função para publicar para todos os usuarios
def publisher(channel, method, properties, msg):
	id_user_msg = str(msg.decode().split("::")[0])
	usuario = reg_clientes[int(msg.decode().split("::")[0])]
	msg_final = "::".join(msg.decode().split("::")[1:])
	msg_envio = True
	#Percorre o dicionario que contém o registro de usuarios no sistema, enviando a mensagem para todos
	for reg_cliente in reg_clientes.keys():
		user_queue = 'in_' + str(reg_cliente)
		#Verifica se a mensagem atual não foi enviada pelo mesmo usuario		
		if msg_final == 'quit' and str(reg_cliente) == id_user_msg:
			print("Cliente "+usuario+"-"+id_user_msg+" saiu do chat.")
			msg_envio = False
			channel.basic_publish(exchange='', routing_key=user_queue, body=msg_final+":")
			break
		elif str(reg_cliente) == id_user_msg:
			pass
		else:
			channel.basic_publish(exchange='', routing_key=user_queue, body=id_user_msg + ": " + msg_final)
	if msg_envio:
		print("Enviando arquivo de: "+usuario+"-"+id_user_msg)



TCP_IP = '192.168.100.6'
TCP_PORT = 7110
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind((TCP_IP, TCP_PORT))
polling = True
polling_thread = threading.Thread(target=polling_cliente)
polling_thread.start()

#Dicionario para armazenas os clientes que entraram no sistema e o seu id
reg_clientes = {}

credentials = pika.PlainCredentials('sdi0001', 'sdi0001')
conexao = pika.BlockingConnection(pika.ConnectionParameters('localhost', 5672, '/', credentials))
canal = conexao.channel()
canal.queue_declare(queue='output')
print ("O servidor foi iniciado")

canal.basic_consume(publisher, queue='output', no_ack=True)
canal.start_consuming()

polling = False

conexao.close()
