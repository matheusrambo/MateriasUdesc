#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pika, threading, socket
#Lista para contar as mensagens recebidas de cada usuario
global msgs_recebidas
global username
global this_id
global polling

msgs_recebidas = []

#Funcao que 'consome' as mensagens na fila do usuario
def consumir_fila():
	credentials = pika.PlainCredentials('sdi0001', 'sdi0001')
	conexao_in = pika.BlockingConnection(pika.ConnectionParameters('localhost', 5672, '/', credentials))
	channel_in = conexao_in.channel()
	this_queue = "in_"+this_id
	channel_in.queue_declare(queue=this_queue)
	channel_in.basic_consume(publisher, queue=this_queue, no_ack=True)
	channel_in.start_consuming()
	channel_in.close()


def publisher(ch, method, properties, body):
	#Filtrando id:dados recebidos em body
	id_msg_recebida = body.decode().split(":")[0]
	dados_recebidos = str(body.decode().split(":")[1])
	#Adicionando o id na lista de msgs
	msgs_recebidas.append(id_msg_recebida)
	nr_msg = msgs_recebidas.count(id_msg_recebida)

	file = str(username)+str(this_id)+".client"+str(id_msg_recebida)+"-"+str(nr_msg)

	with open(file, "w") as fopen:
		fopen.write(dados_recebidos.strip("\n"))

	if not polling:
		print("Finalizando...")
		ch.stop_consuming()



username = input('Digite seu nome: ')

polling = True

TCP_IP = '192.168.100.6'
TCP_PORT = 7110
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((TCP_IP, TCP_PORT))
s.send(username.encode())
this_id = s.recv(1024).decode()
s.close()
print("Seu id definido pelo servidor é:", this_id)

credentials = pika.PlainCredentials('sdi0001', 'sdi0001')
conexao_output = pika.BlockingConnection(pika.ConnectionParameters('localhost', 5672, '/', credentials))
channel_output = conexao_output.channel()
channel_output.queue_declare(queue='output')

consumidor = threading.Thread(target=consumir_fila)
consumidor.start()

print("Conexão concluída e fila criada, insira o nome de um arquivo que deseja enviar.")
while True:
	arquivo = input()
	if arquivo == 'quit':
		channel_output.basic_publish(exchange='', routing_key='output', body=str(this_id)+"::"+"quit")
		polling = False
		break
	
	try:
		with open(arquivo, "r") as fopen:
			dados = str(fopen.read())
	except Exception:
		print("Erro ao abrir o arquivo.")
	else:
		if dados.strip() == '':
			print("Arquivo ("+arquivo+") vazio, descartando envio.")
			continue
		else:
			channel_output.basic_publish(exchange='', routing_key='output', body=str(this_id)+"::"+dados)

channel_output.close()
quit()
