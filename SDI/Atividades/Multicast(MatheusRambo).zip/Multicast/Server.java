import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Vector;

/**
 *
 * @author MatheusRambo 
 */
public class Server extends Thread {

    /**
     * @param args the command line arguments
     */
    public static void main(final String[] args) {
        clientes = new Vector();
        try {
            // criando o socket que escutara na porta 2222
            final ServerSocket s = new ServerSocket(2222);

            // loop principal
            while (true) {
                // fica aguardando ate alguem se conectar no servidor
                System.out.println("Esperando alguem se conectar...");
                final Socket conexao = s.accept();
                System.out.println("Conectou!");

                // cria um thread para receber essa conexão
                final Thread t = new Server(conexao);
                t.start();
                // volta no loop esperando mais alguem se conectar
            }

        } catch (final IOException e) {
            // caso ocorro algum problema de I/O
            System.out.println("IOException: " + e);
        }
    }

    // parte que controla a conexão por meio de threads
    private static Vector clientes;
    // socket do cliente
    private final Socket conexao;
    // nome do cliente
    private String meuNome;

    // contrutor que recebe o socket deste cliente
    public Server(final Socket s) {
        conexao = s;
    }

    // execução da thread
    public void run() {
        try {
            // objetos que permitem controlar fluxo de comunicação
            final BufferedReader entrada = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            final PrintStream saida = new PrintStream(conexao.getOutputStream());

            // primeiramente, espera-se pelo nome do cliente
            meuNome = entrada.readLine();
            // agora verifica se a string e valida
            if (meuNome == null) {
                return;
            }
            // Quando o usuario e valido, adiciona ele ao vetor de clientes
            clientes.add(saida);
            // não há importancia de o cliente ser compartilhado entre varias threads

            // loop principal que espera as strings do cliente
            // ele e quebrado quando o cliente envia linha em branco(interrompida)
            String linha = entrada.readLine();
            while (linha != null && !(linha.trim().equals(""))) {
                // reenvia a linha para todos os clientes conectados
                sendToAll(saida, " escreveu: ", linha);

                // espera por uma nova linha
                linha = entrada.readLine();
            }
            // quando o usuário envia linha em branco, fecha sua conexão
            sendToAll(saida, " saiu ", "do chat!");
            clientes.remove(saida);
            conexao.close();
        } catch (final IOException e) {
            // caso ocorra alguma exeção de I/O
            System.out.println("IOException: " + e);
        }
    }

    // enviar uma mensagem para todos, menos para o próprio
    public void sendToAll(final PrintStream saida, final String acao, final String linha) throws IOException {
        //define o caminho do arquivo que sera utilizado para leitura ou escrita
        //##################################################
        //#                                                #
        //#                                                # 
        //#           MUDE AQUI O SEU CAMINHO              #
        //#                                                #
        //#                                                #
        //##################################################
        File f = new File("C:\\Users\\mathe\\msg.txt");

        //Cria uma instancia do arquivo para escrita
        FileWriter fw = new FileWriter(f, true);    //true pra não substituir tudo

        //Cria a possibilidade de escrever no arquivo
        PrintWriter pw = new PrintWriter(fw);

        Enumeration e = clientes.elements();
        while (e.hasMoreElements()) {
            //obtém o fluxo de saida de um dos clientes
            PrintStream chat = (PrintStream) e.nextElement();
            //envia para todos, menos para o próprio usuário
            if (chat != saida) {
                //realmente escreve no arquivo
                pw.println(meuNome + acao + linha);

                //fecha a conexão do arquivo
                fw.close();
                chat.println(meuNome + acao + linha);
            }
        }
    }
}