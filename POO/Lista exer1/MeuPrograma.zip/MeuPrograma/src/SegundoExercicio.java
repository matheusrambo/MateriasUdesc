import java.util.Scanner;

public class SegundoExercicio {
	private static Scanner in;
	public static void main(String[] args) {
		System.out.printf("Matriz de Ordem 2 ou Ordem 3? ");
		in = new Scanner(System.in);
		int ordem = in.nextInt();	
		int det = 0;
		int m[][] = new int[ordem][ordem];
		if (ordem == 2) {	
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 2; j++) {
					System.out.printf("Valor M[%d][%d]: ", i+1,j+1);
					m[i][j] = in.nextInt();
				}
			}
			
			det = (m[0][0]*m[1][1])-(m[0][1]*m[1][0]);
			
			System.out.println("Matriz:");
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 2; j++) {
					System.out.printf(" "+m[i][j]);
				}
				System.out.println("");				
			}
		}
		
		if(ordem == 3){
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					System.out.printf("Valor M[%d][%d]: ", i+1,j+1);
					m[i][j] = in.nextInt();
				}
			}
			
			det = ((m[0][0]*m[1][1]*m[2][2])+(m[0][1]*m[1][2]*m[2][0])+(m[1][0]*m[2][1]*m[0][2])) - ((m[0][2]*m[1][1]*m[2][0])+(m[0][1]*m[1][0]*m[2][2])+(m[1][2]*m[2][1]*m[0][0]));
			
			System.out.println("Matriz:");
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					System.out.printf(" "+m[i][j]);
				}
				System.out.println("");				
			}

		}
		System.out.println("Determinante: "+det);
	}
}
