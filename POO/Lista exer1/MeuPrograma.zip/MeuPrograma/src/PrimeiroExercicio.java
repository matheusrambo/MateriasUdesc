import java.util.Scanner;

public class PrimeiroExercicio {
	private static Scanner in;
	public static void main(String[] args) {
		int a;
		do {
			System.out.println("\nDigite um n�mero:");
			in = new Scanner(System.in);
			a = in.nextInt();
	    	
			if(a!=1 && a!=0) {
				eratostenes(a);
			}else {
				if(a!=0) {
					System.out.println("1 n�o � v�lido");
				}
			}
		}while(a!=0);
    }

    public static void eratostenes(int a) {
        int maior;
        maior = (int)Math.floor(Math.sqrt(a));
        
        boolean[] primos = new boolean[a + 1];
        for (int i = 2; i < a; i++) {
            primos[i] = true;
        }
        for (int i = 2; i <= maior; i++) {
            if (primos[i]) {
                for (int j = i; i * j <= a; j++) {
                    primos[i * j] = false;
                }
            }
        }
        for (int i = 2; i < primos.length; i++) {
        	if (primos[i]) {
                System.out.print(i+" ");
            }
        }   
    }
}
