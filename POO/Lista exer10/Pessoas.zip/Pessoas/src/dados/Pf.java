package dados;

public class Pf extends Pessoa {
	private String cpf;

	public String getId() {
		return cpf;
	}
}
