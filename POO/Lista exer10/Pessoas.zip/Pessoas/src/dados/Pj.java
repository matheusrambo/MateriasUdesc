package dados;

public class Pj extends Pessoa {
	
	private String cnpj;
	
	public String getId() {
		return cnpj;
	}

}
