package excecoes;

public class PosicaoInvalidaException extends Exception {

	public PosicaoInvalidaException() {
		
	}
	
	
	public PosicaoInvalidaException(String msg) {
		super(msg);
	}
}
