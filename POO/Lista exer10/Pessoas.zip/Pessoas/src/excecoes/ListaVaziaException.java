package excecoes;

public class ListaVaziaException extends Exception {

	public ListaVaziaException() {
		
	}
	
	public ListaVaziaException(String msg) {
		super(msg);
	}
}
