package excecoes;

public class InformacaoNaoEncontrada extends Exception {

	public InformacaoNaoEncontrada() {
		
	}
	
	public InformacaoNaoEncontrada(String msg) {
		super(msg);
	}
	
}
