package logica;

public class Onibus extends Veiculo{
	private int numAssentos;
	private int potenciaCv;
	
	public int getNumAssentos() {
		return numAssentos;
	}
	public void setNumAssentos(int numAssentos) {
		this.numAssentos = numAssentos;
	}
	public int getPotenciaCv() {
		return potenciaCv;
	}
	public void setPotenciaCv(int potenciaCv) {
		this.potenciaCv = potenciaCv;
	}
	
}
