package logica;

public class Moto extends Veiculo {
	private int cilindrada;
	private boolean partidaEletrica;

	public int getCilindrada() {
		return cilindrada;
	}
	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	public boolean isPartidaEletrica() {
		return partidaEletrica;
	}
	public void setPartidaEletrica(boolean partidaEletrica) {
		this.partidaEletrica = partidaEletrica;
	}
	
}
