package apresentacao;

import java.io.IOException;

public class main {	
	public static void main(String[] args) throws IOException {
		TelaMenu tela = new TelaMenu();
		tela.setVisible(true);
	}
}