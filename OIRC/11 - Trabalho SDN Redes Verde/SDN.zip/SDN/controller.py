from pox.core import core  
import pox.openflow.libopenflow_01 as of  
import pox.host_tracker
from pox.lib.revent import *  
from pox.lib.recoco import Timer  
from collections import defaultdict  
from pox.openflow.discovery import Discovery  
from pox.lib.util import dpid_to_str  
import time
import networkx as nx
from pox.lib.addresses import IPAddr, EthAddr
import matplotlib.pyplot as plt
import datetime

class topoDiscovery(EventMixin):

    #dicionário de switches
    switches = {}
    link_list = {}
    g=nx.MultiGraph()
    #table para mapear-> switch, mac e uma porta de saida
    table = {}
    #armazenar dpid_switch. 
    #Funcao: controlar regras ativas do switch
    switch_flows = {}
    #check if switch ja ta config
    #(dpid_switch, 0/1) 0 nao, 1 sim
    switch_conf = {}
    def __init__(self):
        def startup():
            core.openflow.addListeners(self, priority = 0)
            core.openflow_discovery.addListeners(self)
            core.host_tracker.addListenerByName("HostEvent", self._handle_HostEvent)
        core.call_when_ready(startup, ('openflow','openflow_discovery','host_tracker'))
        print("init over")

    def _handle_ConnectionUp(self,event):
      connection = event.connection
      self.switches[dpid_to_str(connection.dpid)] = connection  # Save switch information

    def _handle_HostEvent (self, event):
        port=event.entry.port
        macaddr=str(event.entry.macaddr)

        print("----->hostEvent-mac:",macaddr)

        print("HostEvent:\n")
        print(event.entry.__dict__)

        dpid=dpid_to_str(event.entry.dpid)
        self.link_list[(dpid,macaddr)]=port
        if dpid not in self.g:  
            self.g.add_node(dpid)
            self.switch_conf[dpid]=0
        self.g.add_edge(dpid,macaddr,port)
        print("Vizinhos do nó:",list(self.g.neighbors(macaddr)))
        print("Grafo:",list(self.g.edges))


    def _handle_LinkEvent(self, event):
        l = event.link
        sw1 = dpid_to_str(l.dpid1)
        sw2 = dpid_to_str(l.dpid2)
        pt1 = l.port1
        pt2 = l.port2
        self.link_list[(sw1,sw2)]=pt1
        self.link_list[(sw2,sw1)]=pt2
        if sw1 not in self.g:  
            self.g.add_node(sw1)
        if sw2 not in self.g:  
            self.g.add_node(sw2)
        self.g.add_edge(sw1,sw2,pt1)

        self.switch_conf[sw1]=0
        self.switch_conf[sw2]=0

    def balanceado(self,event):
        lifetime = 18 - datetime.datetime.now().hour 
        
        #s0
        #ip 1-3
        if event.connection.dpid == 1:
            
            #DE H1 PARA S1
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.1"
            msg.actions.append(of.ofp_action_output(port= 4))
            event.connection.send(msg)
            #DE H1 PARA S1
            
            #DE H2 PARA S3
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.2"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H2 PARA S3
            
            #DE H3 PARA S2
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #olocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.3"
            msg.actions.append(of.ofp_action_output(port= 6))
            event.connection.send(msg)
            #DE H3 PARA S2

        #s3
        #ip 4-6
        elif event.connection.dpid == 4: 

            
            #DE H4 PARA S1
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800 
            msg.match.nw_src = "10.0.0.4"
            msg.actions.append(of.ofp_action_output(port= 4))
            event.connection.send(msg)
            #DE H4 PARA S1


            #DE H5 PARA S0
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800 #ipv4
            msg.match.nw_src = "10.0.0.5"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H5 PARA S0



            #DE H6 PARA S2
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.6"
            msg.actions.append(of.ofp_action_output(port= 6))
            event.connection.send(msg)
            #DE H6 PARA S2

        return

    def verde(self,event):
        lifetime = 0

        if datetime.datetime.now().hour < 24 and datetime.datetime.now().hour > 8:
            lifetime = 24  - datetime.datetime.now().hour + 8
    
        else:
            lifetime = 8 - datetime.datetime.now().hour

        #s0
        #ip 1-3
        if event.connection.dpid == 1:
            print("verde s1\n")

            #DE H1 PARA S3
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.1"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H1 PARA S3

            
            #DE H2 PARA S3
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.2"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H2 PARA S3

            #DE H3 PARA S3
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.3"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H3 PARA S3


        #s3
        #ip 4-6
        elif event.connection.dpid == 4:
            print("verde s4\n")

            
            #DE H4 PARA S0
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em em segundos
            msg.match.dl_type = 0x0800 
            msg.match.nw_src = "10.0.0.4"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H4 PARA S0


            #DE H5 PARA S0
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em em segundos
            msg.match.dl_type = 0x0800 #ipv4
            msg.match.nw_src = "10.0.0.5"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H5 PARA S0


            #DE H6 PARA S0
            msg = of.ofp_flow_mod()
            msg.priority=100
            msg.hard_timeout = lifetime*3600 #colocando o lifetime em em segundos
            msg.match.dl_type = 0x0800
            msg.match.nw_src = "10.0.0.6"
            msg.actions.append(of.ofp_action_output(port= 5))
            event.connection.send(msg)
            #DE H6 PARA S0

        return


    def _handle_PacketIn(self, event):
        print("PacketIn-dpid: %s \n" %{dpid_to_str(event.connection.dpid)})

        print("Evento:\n", event.__dict__)
        packet=event.parsed
        print("PacketIn:\n",packet.__dict__)
            
        if datetime.datetime.now().hour >= 8 and datetime.datetime.now().hour < 18:
            print("Utilizando modo BALANCEADO")
            self.balanceado(event)
        else:
            print("Utilizando modo VERDE")
            self.verde(event)


        #s2 e s3 tem que saber as portas
        if event.connection.dpid == 2 or event.connection.dpid == 3:
            #entrada: PORTA 1 ::  saida: PORTA 2
            msg = of.ofp_flow_mod()
            msg.priority=50
            msg.hard_timeout = 90
            msg.match.in_port = 1
            msg.actions.append(of.ofp_action_output(port= 2))
            event.connection.send(msg)

            #entrada: PORTA 2 ::  saida: PORTA 1
            msg = of.ofp_flow_mod()
            msg.priority=50
            msg.hard_timeout = 90
            msg.match.in_port = 2
            msg.actions.append(of.ofp_action_output(port= 1))
            event.connection.send(msg)
    
            #linha para dropar arp
            #no loop
            msg= of.ofp_flow_mod()
            msg.priority=60
            msg.hard_timeout = 90
            msg.match.dl_type = 0x0806
            event.connection.send(msg)
            #linha para dropar arp
            #no loop


        #MAC LEARNING
        self.table[(event.connection,packet.src)] = event.port
        dst_port = self.table.get((event.connection,packet.dst))
        if dst_port is None:
            msg = of.ofp_packet_out(data=event.ofp)
            msg.hard_timeout = 90
            msg.actions.append(of.ofp_action_output(port= of.OFPP_ALL)) 
            event.connection.send(msg)
        else:
            msg = of.ofp_flow_mod()
            msg.match.dl_dst=packet.src
            msg.match.dl_src=packet.dst
            msg.hard_timeout = 90
            msg.actions.append(of.ofp_action_output(port=event.port))
            event.connection.send(msg)
            msg = of.ofp_flow_mod()
            msg.data = event.ofp
            msg.match.dl_src = packet.src
            msg.match.dl_dst = packet.dst
            msg.hard_timeout = 90
            msg.actions.append(of.ofp_action_output(port = dst_port))
            event.connection.send(msg)
        #MAC LEARNING


def launch():  
    core.registerNew(topoDiscovery)
    