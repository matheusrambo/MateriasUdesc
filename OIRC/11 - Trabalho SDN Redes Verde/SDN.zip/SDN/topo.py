#!/usr/bin/python
# -*- coding: utf-8 -*-
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.topo import Topo
from mininet.node import CPULimitedHost
from mininet.util import dumpNodeConnections
from mininet.cli import CLI
from mininet.node import OVSKernelSwitch, RemoteController
from mininet.log import setLogLevel
import time

c0 = RemoteController('c0', ip='127.0.0.1')

class Topo2402(Topo):
    def __init__(self,h=6,s=4,**opts):
        hostttt= ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']
        Topo.__init__(self, **opts)
        switchs = [self.addSwitch('s%d' % j) for j in range(1, s+1)]
        hosts = [self.addHost(hostttt[i], cpu=.5/h) for i in range(0, h)]
        print(hosts,switchs)

        #Switch 0 -> 1
        self.addLink(switchs[0], switchs[1], port1=4, port2=1, cls=TCLink, bw=100, delay='10ms')
        #Switch 0 -> 2
        self.addLink(switchs[0], switchs[2], port1=6, port2=1, cls=TCLink, bw=100, delay='10ms')
        #Switch 0 -> 3
        self.addLink(switchs[0], switchs[3], port1=5, port2=5, cls=TCLink, bw=100, delay='10ms')
        #Switch 1 -> 3
        self.addLink(switchs[1], switchs[3], port1=2, port2=4, cls=TCLink, bw=100, delay='10ms')
        #Switch 2 -> 3
        self.addLink(switchs[2], switchs[3], port1=2, port2=6, cls=TCLink, bw=100, delay='10ms')


        #hosts to switch
        #H1
        self.addLink(hosts[0], switchs[0], port1=0, port2=3, cls=TCLink, bw=100, delay='10ms')
        #H2
        self.addLink(hosts[1], switchs[0], port1=0, port2=2, cls=TCLink, bw=100, delay='10ms')
        #H3
        self.addLink(hosts[2], switchs[0], port1=0, port2=1, cls=TCLink, bw=100, delay='10ms')
        #H4
        self.addLink(hosts[3], switchs[3], port1=0, port2=3, cls=TCLink, bw=100, delay='10ms')
        #H5
        self.addLink(hosts[4], switchs[3], port1=0, port2=2, cls=TCLink, bw=100, delay='10ms')
        #H6
        self.addLink(hosts[5], switchs[3], port1=0, port2=1, cls=TCLink, bw=100, delay='10ms')


def perfTest():
    topo = Topo2402(h=6,s=4)
    net = Mininet( topo=topo, controller=c0, link=TCLink, host=CPULimitedHost, switch=OVSKernelSwitch)
    net.start()

    print("Dumping host connections")
    dumpNodeConnections(net.hosts)
    CLI(net)
#    print("Testando largura de banda entre h1 e h4!")
#    h1, h4 = net.get( 'h1', 'h4' )
#    net.iperf((h1, h4))
#    net.stop()


#função que está no slide do professor
#Serve para medir consumo de banda
def tshark(src, interface, file, duration):
	cmd = ('tshark -i %s -w %s -a duration:%i &' % (interface, file, duration))
	src.cmd(cmd)

	tshark(s1, 's1-eth1', 's1_eth1.pcap', 40) #chama a função para ler da interface eth1 do switch 1 por 40 segundos e salva no arquivo s1_eth1.pcap

if __name__ == '__main__':
    setLogLevel('info')
    perfTest()
