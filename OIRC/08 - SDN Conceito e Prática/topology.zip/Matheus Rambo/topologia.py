#!/usr/bin/python
# -*- coding: utf-8 -*-
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.topo import Topo
from mininet.node import CPULimitedHost
from mininet.cli import CLI
from mininet.node import OVSKernelSwitch, RemoteController
from mininet.log import setLogLevel
import time

c0 = RemoteController('c0', ip='127.0.0.1')

class SimpleTop(Topo):

    '''Simple Topology with two switches and two hosts'''

    def __init__(self,h=6,s=7,**opts):

        Topo.__init__(self, **opts)
        switchs = [self.addSwitch('s%d' % j) for j in range(0, s)]
        hosts = [self.addHost('h%d' % i, cpu=.5/h) for i in range(0, h)]

        #adicionando links 10Gbps
        self.addLink(switchs[0], switchs[1], cls=TCLink, bw=10000,
                     delay='50ms')

        self.addLink(switchs[0], switchs[2], cls=TCLink, bw=10000,
                     delay='50ms')

        #adicionando links 1Gbps
        self.addLink(switchs[1], switchs[3], cls=TCLink, bw=1000,
                     delay='50ms')

        self.addLink(switchs[1], switchs[4], cls=TCLink, bw=1000,
                     delay='50ms')

        self.addLink(switchs[2], switchs[5], cls=TCLink, bw=1000,
                     delay='50ms')

        self.addLink(switchs[2], switchs[6], cls=TCLink, bw=1000,
                     delay='50ms')

        #adicionando links 50Mbps
        self.addLink(switchs[1], hosts[0], cls=TCLink, bw=50,
                     delay='50ms')

        self.addLink(switchs[3], hosts[1], cls=TCLink, bw=50,
                     delay='50ms')

        self.addLink(switchs[4], hosts[2], cls=TCLink, bw=50,
                     delay='50ms')

        self.addLink(switchs[5], hosts[3], cls=TCLink, bw=50,
                     delay='50ms')

        self.addLink(switchs[6], hosts[4], cls=TCLink, bw=50,
                     delay='50ms')

        self.addLink(switchs[2], hosts[5], cls=TCLink, bw=50,
                     delay='50ms')

def runIperfServerTCP(host):
    host.cmd('iperf -s -P 5 &')

def runIperfTCP(src,dst,duration):
    cmd = ('iperf -c %s -i 1 -t %d' % (dst.IP(),duration))
    src.cmdPrint(cmd)

def runIperfTCPLog(src,dst,duration,logfile):
    cmd = ('iperf -c %s -i 1 -t %d >> %s' % (dst.IP(),duration,logfile))
    src.cmdPrint(cmd)


def perfTest():
    topo = SimpleTop(h=6,s=7)
    net = Mininet( topo=topo, controller=c0, link=TCLink, host=CPULimitedHost, switch=OVSKernelSwitch)
    net.start()

    cmd = ('net')
    cmd = ('dump')

    #ping all
    net.pingAll()
    # tempo para estabilizar os links entre os switchs
    time.sleep(5)

    hosts=[]

    #teste ping all manual
    for i in range(0,6):
        hosts.append(net.getNodeByName('h%d' % i))

    for i in range(0,6):
        for j in range(0,6):
            hosts[i].cmdPrint('ping -c 2 %s' % (hosts[j].IP()))

    #teste largura de banda

    for i in range(0, 6):

        print('iperf server: h%d' % i)
        runIperfServerTCP(hosts[i])

        for j in range(0, 6):
            if i==j:
                continue
            print('cliente h%d - servidor h%d' % (j,i))
            runIperfTCPLog(hosts[j],hosts[i],10,'logServ_h%d-Cli_h%d.txt' % (i,j))

    CLI(net)
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    perfTest()
